const SHOP_LAT = 17.9784;
const SHOP_LNG = 79.5941;

function initNavToggle() {
  const toggle = document.querySelector('.nav-toggle');
  const navLinks = document.querySelector('.nav-links');

  if (!toggle || !navLinks) {
    return;
  }

  toggle.addEventListener('click', () => {
    toggle.classList.toggle('open');
    navLinks.classList.toggle('open');
  });
}

function setActiveNavLink() {
  const navLinks = document.querySelectorAll('.nav-link');
  const currentPath = window.location.pathname.toLowerCase();
  navLinks.forEach(link => {
    const href = link.getAttribute('href');
    if (!href) return;
    const normalized = href.toLowerCase();
    if (
      (currentPath.endsWith('index.html') && normalized.includes('index.html')) ||
      (currentPath.endsWith('/') && normalized.includes('index.html')) ||
      (currentPath.includes(normalized) && normalized !== 'index.html')
    ) {
      link.classList.add('active');
    }
  });
}

function initIntersectionObserver() {
  const elements = document.querySelectorAll('.fade-in');
  if (!elements.length) return;

  const observer = new IntersectionObserver(
    entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          observer.unobserve(entry.target);
        }
      });
    },
    {
      threshold: 0.15,
    }
  );

  elements.forEach(element => observer.observe(element));
}

function showFieldError(input, message) {
  const error = input.parentElement.querySelector('.error-text');
  if (error) {
    error.textContent = message;
  }
  input.classList.add('invalid');
}

function clearFieldError(input) {
  const error = input.parentElement.querySelector('.error-text');
  if (error) {
    error.textContent = '';
  }
  input.classList.remove('invalid');
}

function validateContactForm() {
  const form = document.getElementById('enquiry-form');
  if (!form) {
    return;
  }

  const nameInput = document.getElementById('full-name');
  const phoneInput = document.getElementById('phone-number');
  const typeSelect = document.getElementById('enquiry-type');
  const successBox = document.getElementById('form-success');
  const formWrapper = form;

  form.addEventListener('submit', event => {
    event.preventDefault();

    let valid = true;
    const nameValue = nameInput.value.trim();
    const phoneValue = phoneInput.value.trim();
    const typeValue = typeSelect.value;

    clearFieldError(nameInput);
    clearFieldError(phoneInput);
    clearFieldError(typeSelect);

    if (nameValue.length < 3) {
      showFieldError(nameInput, 'Please enter your full name (min 3 characters)');
      valid = false;
    }

    if (!/^[0-9]{10}$/.test(phoneValue)) {
      showFieldError(phoneInput, 'Please enter a valid 10-digit phone number');
      valid = false;
    }

    if (!typeValue || typeValue === 'default') {
      showFieldError(typeSelect, 'Please select an enquiry type');
      valid = false;
    }

    if (!valid) {
      return;
    }

    if (successBox && formWrapper) {
      formWrapper.style.display = 'none';
      successBox.innerHTML = `<div class="success-box fade-in visible">
        <p>✅ Thank you, ${nameValue}!</p>
        <p>Your enquiry has been received. We will call you back on ${phoneValue} within 24 hours.</p>
        <p>— Venkateshwara Beedi Puna, Hanamkonda</p>
        <p>📞 +91 96401 90330</p>
      </div>`;
      successBox.scrollIntoView({ behavior: 'smooth' });
    }
  });
}

function haversineDistance(lat1, lng1, lat2, lng2) {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) * Math.sin(dLng / 2);
  return (R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))).toFixed(1);
}

function initLocationPage() {
  const locationButton = document.getElementById('find-location-btn');
  const locationResult = document.getElementById('location-result');

  if (!locationButton || !locationResult) {
    return;
  }

  function renderMessage(type, html) {
    locationResult.innerHTML = `<div class="result-box ${type}">${html}</div>`;
  }

  function createMapsUrl(lat, lng) {
    return `https://www.google.com/maps/dir/${lat},${lng}/${SHOP_LAT},${SHOP_LNG}`;
  }

  function renderManualButton(label, url) {
    return `<div style="margin-top:18px; display:flex; justify-content:center;">
      <a class="btn btn-primary" href="${url}" target="_blank" rel="noreferrer noopener">${label}</a>
    </div>`;
  }

  locationButton.addEventListener('click', () => {
    renderMessage('info', '📡 Fetching your location...');

    if (!navigator.geolocation) {
      renderMessage('error', '❌ Geolocation is not supported by your browser. Please use the address below or open Google Maps manually.' + renderManualButton('🗺️ Open in Google Maps', `https://www.google.com/maps/search/Brahmana+Wada+Hanamkonda+Telangana+506001`));
      return;
    }

    navigator.geolocation.getCurrentPosition(
      position => {
        const userLat = position.coords.latitude;
        const userLng = position.coords.longitude;
        const distance = haversineDistance(userLat, userLng, SHOP_LAT, SHOP_LNG);
        const mapUrl = createMapsUrl(userLat, userLng);
        renderMessage('success', `📍 You are ${distance} km away from Venkateshwara Beedi Puna.` + renderManualButton('🗺️ Open Google Maps Directions', mapUrl));
        window.open(mapUrl, '_blank');
      },
      error => {
        if (error.code === error.PERMISSION_DENIED) {
          renderMessage('warning', '⚠️ Location access was denied. Please use the address below or open Google Maps manually.' + renderManualButton('🗺️ Open in Google Maps', `https://www.google.com/maps/search/Brahmana+Wada+Hanamkonda+Telangana+506001`));
          return;
        }
        renderMessage('error', '❌ Unable to fetch your location. Please check GPS settings and try again.' + renderManualButton('🗺️ Open in Google Maps', `https://www.google.com/maps/search/Brahmana+Wada+Hanamkonda+Telangana+506001`));
      },
      {
        timeout: 20000,
      }
    );
  });
}

function closeNavOnLinkClick() {
  const links = document.querySelectorAll('.nav-link');
  const toggle = document.querySelector('.nav-toggle');
  const navLinks = document.querySelector('.nav-links');

  links.forEach(link => {
    link.addEventListener('click', () => {
      if (toggle && navLinks && navLinks.classList.contains('open')) {
        toggle.classList.remove('open');
        navLinks.classList.remove('open');
      }
    });
  });
}

document.addEventListener('DOMContentLoaded', () => {
  initNavToggle();
  setActiveNavLink();
  initIntersectionObserver();
  validateContactForm();
  initLocationPage();
  closeNavOnLinkClick();
});
